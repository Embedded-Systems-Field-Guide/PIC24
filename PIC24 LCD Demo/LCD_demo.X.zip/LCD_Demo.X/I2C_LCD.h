/*
 * File:   I2C_LCD.c
 * Author: Damian Erys
 * Created on 19 September 2024, 6:56 PM
 */

#ifndef I2C_LCD_H
#define I2C_LCD_H

#ifndef FCY
 // Unless already defined assume 4MHz instruction clock frequency
 // This definition is required to calibrate __delay_us() and __delay_ms()
 #define FCY 4000000UL
#endif  

#include <libpic30.h>
#include "stdbool.h"

// Functions to initialize the I2C module
void I2C1_Init(void);
void LCD_Write_Byte(char data, char mode);

// LCD functions
void LCD_Init(void);
void LCD_Clear(void);
void LCD_Set_Cursor(char a, char b);
void LCD_Write_Char(char a);
void LCD_Write_String(char *a);
void LCD_Shift_Right(void);
void LCD_Shift_Left(void);
void LCD_ShowCursor(bool EnableCursor);
void LCD_Write_Custom_Char(char row, char col, char *charmap);
void LCD_Backlight_Control(bool state);
void LCD_Clear_Line(char row);

void LCD_Command(char cmd) ;
void LCD_Home() ;
    

#endif // I2C_LCD_H


