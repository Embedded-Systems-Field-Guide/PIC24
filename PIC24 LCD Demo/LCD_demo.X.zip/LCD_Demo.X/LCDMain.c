
// PIC24FJ64GA002 Configuration Bit Settings

// 'C' source line config statements

// CONFIG2
#pragma config POSCMOD = NONE           // Primary Oscillator Select (Primary oscillator disabled)
#pragma config I2C1SEL = PRI            // I2C1 Pin Location Select (Use default SCL1/SDA1 pins)
#pragma config IOL1WAY = OFF            // IOLOCK Protection (IOLOCK may be changed via unlocking seq)
#pragma config OSCIOFNC = OFF           // Primary Oscillator Output Function (OSC2/CLKO/RC15 functions as CLKO (FOSC/2))
#pragma config FCKSM = CSDCMD           // Clock Switching and Monitor (Clock switching and Fail-Safe Clock Monitor are disabled)
#pragma config FNOSC = FRC              // Oscillator Select (Fast RC Oscillator (FRC))
#pragma config SOSCSEL = LPSOSC         // Sec Oscillator Select (Low Power Secondary Oscillator (LPSOSC))
#pragma config WUTSEL = LEG             // Wake-up timer Select (Legacy Wake-up Timer)
#pragma config IESO = OFF               // Internal External Switch Over Mode (IESO mode (Two-Speed Start-up) disabled)

// CONFIG1
#pragma config WDTPS = PS32768          // Watchdog Timer Postscaler (1:32,768)
#pragma config FWPSA = PR128            // WDT Prescaler (Prescaler ratio of 1:128)
#pragma config WINDIS = OFF             // Watchdog Timer Window (Windowed Watchdog Timer enabled; FWDTEN must be 1)
#pragma config FWDTEN = OFF             // Watchdog Timer Enable (Watchdog Timer is disabled)
#pragma config ICS = PGx1               // Comm Channel Select (Emulator EMUC1/EMUD1 pins are shared with PGC1/PGD1)
#pragma config GWRP = OFF               // General Code Segment Write Protect (Writes to program memory are allowed)
#pragma config GCP = OFF                // General Code Segment Code Protect (Code protection is disabled)
#pragma config JTAGEN = OFF             // JTAG Port Enable (JTAG port is disabled)

//------------------------------------------------------------------------------
//  HEADER FILES
//------------------------------------------------------------------------------
#include "xc.h"         
#include "I2C_LCD.h"     
#include "stdbool.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>

char smiley[8] = {
    0b00000,  // Row 0
    0b01010,  // Row 1
    0b01010,  // Row 2
    0b10001,  // Row 3
    0b01110,  // Row 4
    0b00110,  // Row 5
    0b00000,  // Row 6
    0b00000   // Row 7 (Unused)
};
  
char Line1[] = "I2C";
char Line2[] = "LCD";

const int LCDLength = 16;
int Count = 0;
    
int main(void) {
    LCD_Init();
    LCD_ShowCursor(false);
    
    LCD_Home();  //Home works like LCD_Set_Cursor but shorter
    LCD_Write_String("Good luck with");
    LCD_Set_Cursor(1,0);
    LCD_Write_String("REII222!");
    
    LCD_Write_Custom_Char(1, 9, smiley); // Display the smiley face
    __delay_ms(5000);
    
    
    LCD_Clear();
    LCD_Home();  
    LCD_Write_String("Meet Piet the");
    LCD_Set_Cursor(1, 0);
    LCD_Write_String("Plakkie Hunter!");  
    __delay_ms(2000);

 
    LCD_Clear();
    LCD_Home();
    LCD_Write_String("Piet says:");
    LCD_Set_Cursor(1, 0);
    LCD_Write_String("Shoes in the Lab!");  
    __delay_ms(2000);

    //Here we Clear one line to save some processing power
    //Additionally we write a string next to existing string
    LCD_Clear_Line(1); 
    LCD_Set_Cursor(0, 10);
    //Example of writing 1 char at a time. Note single quotes
    LCD_Write_Char('I');
    LCD_Write_Char('\'');//Output a single quote
    LCD_Write_Char('l');
    LCD_Write_Char('l');
    LCD_Set_Cursor(1, 0);
    LCD_Write_String("Break your neck");  
    __delay_ms(2000);

    // Ending message
    LCD_Clear();
    LCD_Home();  
    LCD_Write_String("Courtesy of your");
    LCD_Set_Cursor(1, 0);
    LCD_Write_String("Favorite Demi!");

    __delay_ms(2000);
    
    LCD_Clear();
    LCD_Home();  
    LCD_Write_String(Line1);
    LCD_Set_Cursor(1, 0);
    LCD_Write_String(Line2);
    

    bool direction = true; // true for right, false for left
    int LineLength = strlen(Line1) > strlen(Line2) ? strlen(Line1) : strlen(Line2); 
    while(1) {
        __delay_ms(250);

        if (direction) {
            // Move right
            if (Count < LCDLength - LineLength) {
                LCD_Shift_Right();
                Count++;
                
            } else {
                // Reached the right edge, switch direction
                direction = false;
            }
        } else {
            // Move left
            if (Count > 0) {
                LCD_Shift_Left();
                Count--;
            } else {
                // Reached the left edge, switch direction
                direction = true;
            }
        }
    }
    return 0;
}
