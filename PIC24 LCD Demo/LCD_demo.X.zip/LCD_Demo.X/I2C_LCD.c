/*
 * File:   I2C_LCD.c
 * Author: Damian Erys
 * Contains all the functions defined as prototypes in I2C_LCD.h
 * Created on 19 September 2024, 6:56 PM
 */

//=========================================
/*
This file, I2C_LCD.c, provides the implementation of functions for controlling 
 * a 16x2 LCD display via the I2C protocol, specifically designed for use with 
 * the current microcontroller unit (PIC24) on pins 18 and 19 by default. The 
 * functions include initialization, data writing, command execution, and 
 * cursor management, facilitating the display of characters and custom 
 * graphics. The code is structured to support easy integration into projects 
 * requiring visual output.
 */
//=========================================
#include "xc.h"        // Include the PIC microcontroller library
#include "I2C_LCD.h"   // Include the custom LCD header file
#include "stdbool.h"   // Include support for boolean types
#include <stdint.h>    // Include support for standard integer types

// Define constants for the I2C LCD module
#define LCD_ADDR 0x27         // I2C address for the LCD (change if needed for your hardware)
#define LCD_BACKLIGHT 0x08    // Turn on the LCD backlight
#define LCD_ENABLE 0x04       // Enable signal bit for the LCD
#define LCD_COMMAND 0x00      // Indicates the data being sent is a command
#define LCD_DATA 0x01         // Indicates the data being sent is character data
#define LCD_CGRAM_ADDR 0x40   // Starting address for custom character memory (CGRAM)

// Function to initialize the I2C1 module for communication
void I2C1_Init(void) {
    I2C1BRG = 0x9D;            // Set the baud rate generator for 100kHz I2C clock (with Fosc = 8MHz)
    I2C1CONbits.I2CEN = 1;     // Enable the I2C module for communication
}

// Function to toggle the visibility of the LCD cursor
void LCD_ShowCursor(bool EnableCursor) {
    if (EnableCursor) {
        LCD_Command(0x0F);  // Command: Display ON, cursor ON, and blinking ON
    } else {
        LCD_Command(0x0C);  // Command: Display ON, cursor OFF
    }
}

// Function to send data to the I2C bus (writes data to a device via I2C)
void I2C_Write(unsigned char address, unsigned char data) {
    I2C1CONbits.SEN = 1;             // Initiate a start condition on the I2C bus
    while (I2C1CONbits.SEN);         // Wait until the start condition is completed

    IFS1bits.MI2C1IF = 0;            // Clear the I2C1 interrupt flag
    I2C1TRN = address << 1;          // Send the I2C address (shifted left by 1 for the write bit)
    while (I2C1STATbits.TRSTAT);     // Wait for the transmission to complete
    while (!IFS1bits.MI2C1IF);       // Wait for the interrupt flag
    IFS1bits.MI2C1IF = 0;            // Clear the interrupt flag

    I2C1TRN = data;                  // Send the actual data byte
    while (I2C1STATbits.TRSTAT);     // Wait for transmission to complete
    while (!IFS1bits.MI2C1IF);       // Wait for the interrupt flag
    IFS1bits.MI2C1IF = 0;            // Clear the interrupt flag

    I2C1CONbits.PEN = 1;             // Initiate a stop condition
    while (I2C1CONbits.PEN);         // Wait until the stop condition is completed
}

// Function to send a command to the LCD
void LCD_Command(char cmd) {
    LCD_Write_Byte(cmd, LCD_COMMAND);  // Use helper function to send a command byte
}

// Function to send a character to the LCD (to display)
void LCD_Write_Char(char data) {
    LCD_Write_Byte(data, LCD_DATA);    // Use helper function to send data as a character
}

// Function to initialize the LCD display (using I2C)
void LCD_Init(void) {
    I2C1_Init();  // Initialize I2C module first

    // Send initialization commands for the LCD to operate in 4-bit mode
    LCD_Write_Byte(0x33, 0);  // Initialize LCD
    LCD_Write_Byte(0x32, 0);  // Set LCD to 4-bit mode
    LCD_Write_Byte(0x28, 0);  // Configure for 2 lines, 5x7 character matrix
    LCD_Write_Byte(0x0C, 0);  // Display ON, cursor OFF
    LCD_Write_Byte(0x06, 0);  // Move cursor to the right after each character
    LCD_Clear();               // Clear the display
}

// Function to clear the entire LCD screen
void LCD_Clear() {
    LCD_Command(0x01);   // Command to clear the display
    __delay_ms(2);       // Wait for the command to complete (LCD needs time)
}

// Function to move the cursor to the home position (top-left)
void LCD_Home() {
    LCD_Command(0x02);   // Command to return cursor to home
    __delay_ms(2);       // Wait for the command to complete
}

// Function to set the cursor to a specific row and column
void LCD_Set_Cursor(char row, char col) {
    // Memory addresses for the start of each line (varies by LCD size)
    char row_offsets[] = {0x00, 0x40, 0x14, 0x54};
    // Set the cursor to the desired position
    LCD_Command(0x80 | (col + row_offsets[(int)row]));
}

// Function to write a string of characters to the LCD
void LCD_Write_String(char *str) {
    while (*str) {
        LCD_Write_Char(*str++);  // Write each character of the string to the LCD
    }
}

// Function to shift the entire display to the right
void LCD_Shift_Right() {
    LCD_Command(0x1C);  // Command to shift display right
}

// Function to shift the entire display to the left
void LCD_Shift_Left() {
    LCD_Command(0x18);  // Command to shift display left
}

// Function to send a byte to the LCD (high nibble, then low nibble)
void LCD_Write_Byte(char data, char mode) {
    char high_nibble = data & 0xF0;             
    char low_nibble = (data << 4) & 0xF0;        

    // Send the high nibble
    I2C_Write(LCD_ADDR, high_nibble | mode | LCD_BACKLIGHT | LCD_ENABLE);
    __delay_us(100);   // Small delay after sending
    I2C_Write(LCD_ADDR, high_nibble | mode | LCD_BACKLIGHT);  // Clear the enable bit
    __delay_us(100);   // Another small delay

    // Send the low nibble
    I2C_Write(LCD_ADDR, low_nibble | mode | LCD_BACKLIGHT | LCD_ENABLE);
    __delay_us(100);   // Small delay after sending
    I2C_Write(LCD_ADDR, low_nibble | mode | LCD_BACKLIGHT);  // Clear the enable bit
    __delay_us(100);   // Another small delay
}

// Function to write a custom character to the LCD (stored in CGRAM)
void LCD_Write_Custom_Char(char row, char col, char *charmap) {
    // Ensure the row and column are within valid ranges (row: 0-1, col: 0-15)
    if (row < 0 || row > 1 || col < 0 || col > 15) return;

    // Set the CGRAM address for custom character storage
    LCD_Command(0x40 + (0 * 8));  // Using CGRAM location 0 for custom character

    // Write each byte of the custom character to CGRAM
    for (int i = 0; i < 8; i++) {
        LCD_Write_Char(charmap[i]);
    }

    // Move the cursor to the specified position
    LCD_Set_Cursor(row, col);

    // Write the custom character (stored in CGRAM) to the display
    LCD_Write_Char(0);  // Write character from CGRAM location 0
}

// Function to clear a specific line on the LCD
void LCD_Clear_Line(char row) {
    LCD_Set_Cursor(row, 0);  // Move the cursor to the beginning of the row
    // Write spaces to clear the entire line
    for (int i = 0; i < 16; i++) {
        LCD_Write_Char(' ');
    }
}
